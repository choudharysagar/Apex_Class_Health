import { LightningElement, api } from 'lwc';

export default class ApexClassCoverageLink extends LightningElement {
    @api value;
    @api rowId;
    @api isTest;
    @api toneClass;

    get hasCoverage() {
        return typeof this.value === 'number';
    }

    get linkClass() {
        return `slds-button ${this.toneClass}`;
    }

    handleClick() {
        // Composed so it escapes the datatable's shadow tree and reaches the page component.
        this.dispatchEvent(
            new CustomEvent('coverageclick', { detail: { rowId: this.rowId }, bubbles: true, composed: true })
        );
    }
}
