import { api } from 'lwc';
import LightningModal from 'lightning/modal';

const REQUIRED_COVERAGE = 75;

export default class ApexClassCoverageModal extends LightningModal {
    @api items = [];
    @api nameLabel = 'Class';
    @api coverageLabel = 'Coverage';
    @api summary;
    @api notice;
    @api emptyMessage = 'No coverage data found.';

    get columns() {
        return [
            { label: this.nameLabel, fieldName: 'name' },
            {
                label: this.coverageLabel,
                fieldName: 'coveragePercent',
                type: 'percent',
                typeAttributes: { maximumFractionDigits: 2 },
                cellAttributes: { class: { fieldName: 'coverageClass' } }
            },
            { label: 'Lines Covered', fieldName: 'linesLabel' }
        ];
    }

    get rows() {
        return this.items.map((item) => {
            const hasCoverage = typeof item.coverage === 'number';
            let coverageClass = '';
            if (hasCoverage) {
                coverageClass =
                    item.coverage >= REQUIRED_COVERAGE ? 'slds-text-color_success' : 'slds-text-color_error';
            }
            return {
                ...item,
                coverageClass,
                coveragePercent: hasCoverage ? item.coverage / 100 : null,
                linesLabel: hasCoverage ? `${item.linesCovered} / ${item.linesTotal}` : ''
            };
        });
    }

    get hasItems() {
        return this.items.length > 0;
    }

    get passedLabel() {
        return `${this.summary.methodsPassed} passed`;
    }

    get failedLabel() {
        return `${this.summary.failures.length} failed`;
    }

    get failedBadgeClass() {
        return this.summary.failures.length ? 'slds-theme_error' : '';
    }

    get failures() {
        return this.summary.failures.map((failure, index) => ({ ...failure, key: `${index}` }));
    }

    get hasFailures() {
        return this.summary.failures.length > 0;
    }

    handleClose() {
        this.close();
    }
}
