import LightningDatatable from 'lightning/datatable';
import gradeBadgeTemplate from './gradeBadge.html';
import coverageLinkTemplate from './coverageLink.html';

export default class ApexClassHealthDatatable extends LightningDatatable {
    static customTypes = {
        gradeBadge: {
            template: gradeBadgeTemplate,
            standardCellLayout: true,
            typeAttributes: ['badgeClass']
        },
        coverageLink: {
            template: coverageLinkTemplate,
            standardCellLayout: true,
            typeAttributes: ['rowId', 'isTest', 'toneClass']
        }
    };
}
