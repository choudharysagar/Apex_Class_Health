import { LightningElement, wire } from 'lwc';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getApexClassHealth from '@salesforce/apex/ApexClassHealthController.getApexClassHealth';
import runTests from '@salesforce/apex/ApexClassHealthController.runTests';
import getTestRunStatus from '@salesforce/apex/ApexClassHealthController.getTestRunStatus';
import getClassesCoveredByTests from '@salesforce/apex/ApexClassHealthController.getClassesCoveredByTests';
import getTestsCoveringClass from '@salesforce/apex/ApexClassHealthController.getTestsCoveringClass';
import ApexClassCoverageModal from 'c/apexClassCoverageModal';

const ALL = 'all';
const SEARCH_DELAY_MS = 300;
const POLL_INTERVAL_MS = 5000;
const RUN_TESTS_ACTION = 'run_tests';
const DEFAULT_PAGE_SIZE = 25;
const REQUIRED_COVERAGE = 75;
const GRADES = ['A', 'B', 'C', 'D'];
const GRADE_BADGE_CLASSES = {
    A: 'slds-theme_success',
    B: 'slds-badge_inverse',
    C: 'slds-theme_warning',
    D: 'slds-theme_error'
};
const GRADE_HELP_TEXT =
    'A: coverage of 90% or more. B: 75% or more. C: 50% or more. D: below 50% or no coverage data. ' +
    'A class drops one grade if its API version is more than 3 years behind the newest class, and another ' +
    'if it has more than 1,000 lines. Test classes, and all classes when coverage is unavailable, are graded ' +
    'on API version and size only.';

const COLUMNS = [
    {
        label: 'Run Tests',
        hideLabel: true,
        type: 'button-icon',
        fixedWidth: 50,
        typeAttributes: {
            iconName: 'utility:play',
            name: RUN_TESTS_ACTION,
            title: 'Run tests',
            alternativeText: 'Run tests',
            variant: 'bare'
        }
    },
    {
        label: 'Class Name',
        fieldName: 'classUrl',
        type: 'url',
        sortable: true,
        initialWidth: 240,
        typeAttributes: {
            label: { fieldName: 'name' },
            tooltip: { fieldName: 'name' },
            target: '_blank'
        }
    },
    {
        label: 'Grade',
        fieldName: 'grade',
        type: 'gradeBadge',
        sortable: true,
        initialWidth: 90,
        typeAttributes: { badgeClass: { fieldName: 'gradeClass' } }
    },
    {
        label: 'Coverage',
        fieldName: 'coveragePercent',
        type: 'coverageLink',
        sortable: true,
        typeAttributes: {
            rowId: { fieldName: 'id' },
            isTest: { fieldName: 'isTest' },
            toneClass: { fieldName: 'coverageClass' }
        }
    },
    { label: 'Lines of Code', fieldName: 'linesOfCode', type: 'number', sortable: true },
    { label: 'Characters', fieldName: 'characters', type: 'number', sortable: true },
    {
        label: 'API Version',
        fieldName: 'apiVersion',
        type: 'number',
        sortable: true,
        typeAttributes: { minimumFractionDigits: 1 }
    },
    { label: 'Type', fieldName: 'typeLabel', sortable: true },
    { label: 'Last Modified By', fieldName: 'lastModifiedBy', sortable: true },
    {
        label: 'Last Modified',
        fieldName: 'lastModifiedDate',
        type: 'date',
        sortable: true,
        typeAttributes: { year: 'numeric', month: 'short', day: '2-digit' }
    },
    { label: 'Findings', fieldName: 'findings', wrapText: true, initialWidth: 260 }
];

const EXPORT_COLUMNS = [
    { label: 'Class Name', fieldName: 'name' },
    { label: 'Grade', fieldName: 'grade' },
    { label: 'Coverage %', fieldName: 'coverage' },
    { label: 'Lines Covered', fieldName: 'linesCovered' },
    { label: 'Lines Uncovered', fieldName: 'linesUncovered' },
    { label: 'Lines of Code', fieldName: 'linesOfCode' },
    { label: 'Characters', fieldName: 'characters' },
    { label: 'API Version', fieldName: 'apiVersion' },
    { label: 'Type', fieldName: 'typeLabel' },
    { label: 'Last Modified By', fieldName: 'lastModifiedBy' },
    { label: 'Last Modified', fieldName: 'lastModifiedDate' },
    { label: 'Findings', fieldName: 'findings' }
];

// The class link column displays a URL but should sort by class name.
const SORT_FIELDS = { classUrl: 'name' };

const GRADE_OPTIONS = [
    { label: 'All grades', value: ALL },
    ...GRADES.map((grade) => ({ label: `Grade ${grade}`, value: grade }))
];
const TYPE_OPTIONS = [
    { label: 'All types', value: ALL },
    { label: 'Classes', value: 'class' },
    { label: 'Test classes', value: 'test' }
];
const COVERAGE_OPTIONS = [
    { label: 'All coverage', value: ALL },
    { label: `${REQUIRED_COVERAGE}% or more`, value: 'meets' },
    { label: `Below ${REQUIRED_COVERAGE}%`, value: 'below' },
    { label: 'No coverage data', value: 'none' }
];
const PAGE_SIZE_OPTIONS = ['10', '25', '50', '100'].map((size) => ({ label: size, value: size }));

const isBlank = (value) => value === null || value === undefined || value === '';

function toRow(item) {
    const hasCoverage = typeof item.coverage === 'number';
    let coverageClass = '';
    if (hasCoverage) {
        coverageClass = item.coverage >= REQUIRED_COVERAGE ? 'slds-text-color_success' : 'slds-text-color_error';
    }
    return {
        ...item,
        hasCoverage,
        coverageClass,
        coveragePercent: hasCoverage ? item.coverage / 100 : null,
        classUrl: `/lightning/setup/ApexClasses/page?address=%2F${item.id}`,
        typeKey: item.isTest ? 'test' : 'class',
        typeLabel: item.isTest ? 'Test Class' : 'Class',
        gradeClass: GRADE_BADGE_CLASSES[item.grade],
        searchText: `${item.name} ${item.lastModifiedBy ?? ''}`.toLowerCase()
    };
}

function matchesCoverage(row, filter) {
    switch (filter) {
        case 'meets':
            return row.hasCoverage && row.coverage >= REQUIRED_COVERAGE;
        case 'below':
            return row.hasCoverage && row.coverage < REQUIRED_COVERAGE;
        case 'none':
            return !row.isTest && !row.hasCoverage;
        default:
            return true;
    }
}

function compareRows(left, right, field, direction) {
    const a = left[field];
    const b = right[field];
    if (isBlank(a) !== isBlank(b)) {
        // Blank values always sort last, whatever the direction.
        return isBlank(a) ? 1 : -1;
    }
    let result = 0;
    if (!isBlank(a)) {
        result =
            typeof a === 'string' ? a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }) : a - b;
    }
    return result * direction || left.name.localeCompare(right.name);
}

function summarize(rows, triggerCharacters) {
    const gradeCounts = Object.fromEntries(GRADES.map((grade) => [grade, 0]));
    let linesOfCode = 0;
    // Matches Setup's "Percent of Apex Used": triggers count, comments and test classes don't.
    let characters = triggerCharacters;
    let linesCovered = 0;
    let executableLines = 0;
    rows.forEach((row) => {
        gradeCounts[row.grade] += 1;
        linesOfCode += row.linesOfCode;
        if (!row.isTest) {
            characters += row.characters;
        }
        if (row.hasCoverage) {
            linesCovered += row.linesCovered;
            executableLines += row.linesCovered + row.linesUncovered;
        }
    });
    return {
        totalClasses: rows.length,
        linesOfCode,
        characters,
        hasCoverage: executableLines > 0,
        coverage: executableLines > 0 ? linesCovered / executableLines : null,
        grades: GRADES.map((grade) => ({
            grade,
            label: `${grade}: ${gradeCounts[grade]}`,
            badgeClass: `${GRADE_BADGE_CLASSES[grade]} slds-var-m-right_xx-small`
        }))
    };
}

function toCsvCell(value) {
    if (isBlank(value)) {
        return '';
    }
    const text = String(value);
    // Prefix values a spreadsheet would evaluate as a formula (CSV injection).
    const safeText = /^[=+\-@\t\r]/.test(text) ? `'${text}` : text;
    return `"${safeText.replaceAll('"', '""')}"`;
}

function getErrorMessage(error) {
    return error?.body?.message ?? error?.message ?? 'An unexpected error occurred.';
}

function describeTestClasses(count) {
    return `${count} test ${count === 1 ? 'class' : 'classes'}`;
}

export default class ApexClassHealth extends LightningElement {
    columns = COLUMNS;
    gradeOptions = GRADE_OPTIONS;
    typeOptions = TYPE_OPTIONS;
    coverageOptions = COVERAGE_OPTIONS;
    pageSizeOptions = PAGE_SIZE_OPTIONS;
    gradeHelpText = GRADE_HELP_TEXT;

    allRows = [];
    filteredRows = [];
    summary;
    coverageMessage;
    error;
    isLoading = true;

    searchTerm = '';
    gradeFilter = ALL;
    typeFilter = ALL;
    coverageFilter = ALL;
    sortedBy = 'classUrl';
    sortDirection = 'asc';
    pageSize = DEFAULT_PAGE_SIZE;
    pageNumber = 1;

    selectedIds = new Set();
    activeRun;
    lastRun;

    wiredReport;
    searchTimer;
    pollTimer;

    @wire(getApexClassHealth)
    wiredApexClassHealth(result) {
        this.wiredReport = result;
        const { data, error } = result;
        if (data) {
            this.allRows = data.classes.map(toRow);
            this.summary = summarize(this.allRows, data.triggerCharacters);
            this.coverageMessage = data.coverageMessage;
            this.error = undefined;
            this.applyView();
            this.isLoading = false;
        } else if (error) {
            this.error = getErrorMessage(error);
            this.isLoading = false;
        }
    }

    disconnectedCallback() {
        clearTimeout(this.searchTimer);
        clearTimeout(this.pollTimer);
        this.activeRun = undefined;
    }

    get pagedRows() {
        return this.filteredRows.slice(this.rowNumberOffset, this.rowNumberOffset + this.pageSize);
    }

    get rowNumberOffset() {
        return (this.pageNumber - 1) * this.pageSize;
    }

    get totalPages() {
        return Math.max(1, Math.ceil(this.filteredRows.length / this.pageSize));
    }

    get hasResults() {
        return this.filteredRows.length > 0;
    }

    get resultsLabel() {
        const total = this.filteredRows.length;
        if (!total) {
            return `Showing 0 of ${this.allRows.length} classes`;
        }
        const end = Math.min(this.rowNumberOffset + this.pageSize, total);
        return `Showing ${this.rowNumberOffset + 1}–${end} of ${total} classes`;
    }

    get pageLabel() {
        return `Page ${this.pageNumber} of ${this.totalPages}`;
    }

    get pageSizeValue() {
        return String(this.pageSize);
    }

    get isFirstPage() {
        return this.pageNumber <= 1;
    }

    get isLastPage() {
        return this.pageNumber >= this.totalPages;
    }

    get hasActiveFilters() {
        return (
            Boolean(this.searchTerm.trim()) ||
            this.gradeFilter !== ALL ||
            this.typeFilter !== ALL ||
            this.coverageFilter !== ALL
        );
    }

    get isClearFiltersDisabled() {
        return !this.hasActiveFilters;
    }

    get isExportDisabled() {
        return this.isLoading || Boolean(this.error) || !this.hasResults;
    }

    get selectedRowIds() {
        return this.pagedRows.filter((row) => this.selectedIds.has(row.id)).map((row) => row.id);
    }

    get runTestsLabel() {
        return this.selectedIds.size ? `Run Tests (${this.selectedIds.size})` : 'Run Tests';
    }

    get isRunTestsDisabled() {
        return !this.selectedIds.size || Boolean(this.activeRun);
    }

    get runProgressLabel() {
        const { classesTotal, classesCompleted } = this.activeRun;
        return classesTotal
            ? `Running ${describeTestClasses(classesTotal)}: ${classesCompleted} finished.`
            : 'Queuing tests...';
    }

    get runProgressValue() {
        const { classesTotal, classesCompleted } = this.activeRun;
        return classesTotal ? Math.round((classesCompleted / classesTotal) * 100) : 0;
    }

    get lastRunLabel() {
        const { methodsPassed, failures } = this.lastRun.summary;
        return `Last test run: ${methodsPassed} passed, ${failures.length} failed.`;
    }

    handleSearch(event) {
        this.searchTerm = event.detail.value;
        clearTimeout(this.searchTimer);
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.searchTimer = setTimeout(() => this.resetPagingAndApply(), SEARCH_DELAY_MS);
    }

    handleFilterChange(event) {
        this[event.target.dataset.filter] = event.detail.value;
        this.resetPagingAndApply();
    }

    handleClearFilters() {
        clearTimeout(this.searchTimer);
        this.searchTerm = '';
        this.gradeFilter = ALL;
        this.typeFilter = ALL;
        this.coverageFilter = ALL;
        this.resetPagingAndApply();
    }

    handleSort(event) {
        this.sortedBy = event.detail.fieldName;
        this.sortDirection = event.detail.sortDirection;
        this.resetPagingAndApply();
    }

    handlePageSizeChange(event) {
        this.pageSize = Number(event.detail.value);
        this.pageNumber = 1;
    }

    handlePageNavigation(event) {
        const targetPages = {
            first: 1,
            previous: this.pageNumber - 1,
            next: this.pageNumber + 1,
            last: this.totalPages
        };
        const target = targetPages[event.target.dataset.page];
        this.pageNumber = Math.min(Math.max(target, 1), this.totalPages);
    }

    async handleRefresh() {
        this.isLoading = true;
        try {
            await refreshApex(this.wiredReport);
        } catch (error) {
            this.error = getErrorMessage(error);
        } finally {
            this.isLoading = false;
        }
    }

    handleExport() {
        const header = EXPORT_COLUMNS.map((column) => toCsvCell(column.label)).join(',');
        const lines = this.filteredRows.map((row) =>
            EXPORT_COLUMNS.map((column) => toCsvCell(row[column.fieldName])).join(',')
        );
        const link = document.createElement('a');
        // %EF%BB%BF is a UTF-8 byte order mark so Excel detects the encoding.
        link.href = `data:text/csv;charset=utf-8,%EF%BB%BF${encodeURIComponent([header, ...lines].join('\r\n'))}`;
        link.download = `apex-class-health-${new Date().toISOString().slice(0, 10)}.csv`;
        link.click();
    }

    handleRowSelection(event) {
        // The datatable only reports the current page, so merge it into the selection kept across pages.
        const selectedIds = new Set(this.selectedIds);
        this.pagedRows.forEach((row) => selectedIds.delete(row.id));
        event.detail.selectedRows.forEach((row) => selectedIds.add(row.id));
        this.selectedIds = selectedIds;
    }

    handleRunSelectedTests() {
        this.startTestRun([...this.selectedIds]);
    }

    handleRowAction(event) {
        if (event.detail.action.name === RUN_TESTS_ACTION) {
            this.startTestRun([event.detail.row.id]);
        }
    }

    async handleCoverageClick(event) {
        const row = this.allRows.find((item) => item.id === event.detail.rowId);
        this.isLoading = true;
        try {
            const items = row.isTest
                ? await getClassesCoveredByTests({ testClassIds: [row.id] })
                : await getTestsCoveringClass({ classId: row.id });
            ApexClassCoverageModal.open({
                size: 'medium',
                label: row.isTest ? `Classes Covered by ${row.name}` : `Tests Covering ${row.name}`,
                description: `Code coverage details for ${row.name}`,
                items,
                nameLabel: row.isTest ? 'Class' : 'Test Class',
                coverageLabel: row.isTest ? 'Overall Coverage' : `Coverage of ${row.name}`,
                emptyMessage: row.isTest
                    ? 'No coverage is recorded for this test class yet. Run it to see which classes it covers.'
                    : 'No test class covers this class yet.'
            });
        } catch (error) {
            this.showToast('error', 'Coverage details unavailable', getErrorMessage(error));
        } finally {
            this.isLoading = false;
        }
    }

    handleViewLastRun() {
        this.openRunResults();
    }

    async startTestRun(classIds) {
        if (this.activeRun) {
            this.showToast('info', 'Tests are already running', 'Wait for the current run to finish.');
            return;
        }
        this.activeRun = { classesTotal: 0, classesCompleted: 0 };
        try {
            const run = await runTests({ classIds });
            this.selectedIds = new Set();
            this.activeRun = { ...run, classesTotal: run.testClassIds.length, classesCompleted: 0 };
            const skipped = run.classesWithoutTests.length
                ? ` No tests found for ${run.classesWithoutTests.join(', ')}.`
                : '';
            this.showToast(
                skipped ? 'warning' : 'success',
                'Tests queued',
                `Running ${describeTestClasses(run.testClassIds.length)}.${skipped}`
            );
            this.schedulePoll();
        } catch (error) {
            this.activeRun = undefined;
            this.showToast('error', 'Tests could not be started', getErrorMessage(error));
        }
    }

    schedulePoll() {
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.pollTimer = setTimeout(() => this.pollTestRun(), POLL_INTERVAL_MS);
    }

    async pollTestRun() {
        try {
            const status = await getTestRunStatus({ jobId: this.activeRun.jobId });
            // The component was removed from the page while the status was loading.
            if (!this.activeRun) {
                return;
            }
            if (status.isComplete) {
                await this.finishTestRun(status);
            } else {
                this.activeRun = { ...this.activeRun, ...status };
                this.schedulePoll();
            }
        } catch (error) {
            this.activeRun = undefined;
            this.showToast('error', 'Test run status unavailable', getErrorMessage(error));
        }
    }

    async finishTestRun(summary) {
        const { testClassIds } = this.activeRun;
        this.activeRun = undefined;
        let items = [];
        let notice;
        try {
            items = await getClassesCoveredByTests({ testClassIds });
        } catch (error) {
            notice = `Coverage details are unavailable: ${getErrorMessage(error)}`;
        }
        this.lastRun = { summary, items, notice };
        this.openRunResults();
        this.handleRefresh();
    }

    openRunResults() {
        ApexClassCoverageModal.open({
            size: 'medium',
            label: 'Test Run Results',
            description: 'Test outcomes and the classes covered by the test run',
            summary: this.lastRun.summary,
            items: this.lastRun.items,
            notice: this.lastRun.notice,
            nameLabel: 'Class',
            coverageLabel: 'Overall Coverage',
            emptyMessage: 'No per-test coverage was recorded for this run.'
        });
    }

    showToast(variant, title, message) {
        this.dispatchEvent(new ShowToastEvent({ variant, title, message }));
    }

    resetPagingAndApply() {
        this.pageNumber = 1;
        this.applyView();
    }

    applyView() {
        const term = this.searchTerm.trim().toLowerCase();
        const field = SORT_FIELDS[this.sortedBy] ?? this.sortedBy;
        const direction = this.sortDirection === 'asc' ? 1 : -1;
        this.filteredRows = this.allRows
            .filter(
                (row) =>
                    (!term || row.searchText.includes(term)) &&
                    (this.gradeFilter === ALL || row.grade === this.gradeFilter) &&
                    (this.typeFilter === ALL || row.typeKey === this.typeFilter) &&
                    matchesCoverage(row, this.coverageFilter)
            )
            .sort((left, right) => compareRows(left, right, field, direction));
        this.pageNumber = Math.min(this.pageNumber, this.totalPages);
    }
}
