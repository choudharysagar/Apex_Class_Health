import { createElement } from '@lwc/engine-dom';
import ApexClassHealth from 'c/apexClassHealth';
import ApexClassCoverageModal from 'c/apexClassCoverageModal';
import getApexClassHealth from '@salesforce/apex/ApexClassHealthController.getApexClassHealth';
import runTests from '@salesforce/apex/ApexClassHealthController.runTests';
import getTestRunStatus from '@salesforce/apex/ApexClassHealthController.getTestRunStatus';
import getClassesCoveredByTests from '@salesforce/apex/ApexClassHealthController.getClassesCoveredByTests';
import getTestsCoveringClass from '@salesforce/apex/ApexClassHealthController.getTestsCoveringClass';

jest.mock(
    '@salesforce/apex/ApexClassHealthController.getApexClassHealth',
    () => {
        const { createApexTestWireAdapter } = require('@salesforce/sfdx-lwc-jest');
        return { default: createApexTestWireAdapter(jest.fn()) };
    },
    { virtual: true }
);
jest.mock('@salesforce/apex/ApexClassHealthController.runTests', () => ({ default: jest.fn() }), { virtual: true });
jest.mock('@salesforce/apex/ApexClassHealthController.getTestRunStatus', () => ({ default: jest.fn() }), {
    virtual: true
});
jest.mock('@salesforce/apex/ApexClassHealthController.getClassesCoveredByTests', () => ({ default: jest.fn() }), {
    virtual: true
});
jest.mock('@salesforce/apex/ApexClassHealthController.getTestsCoveringClass', () => ({ default: jest.fn() }), {
    virtual: true
});
jest.mock('c/apexClassCoverageModal', () => ({ __esModule: true, default: { open: jest.fn() } }));

const GRADES = ['A', 'B', 'C', 'D'];
const JOB_ID = '707000000000001AAA';
const TEST_CLASS_ID = '01p000000000000000';

function buildReport({ coverageAvailable = true } = {}) {
    const classes = Array.from({ length: 30 }, (_, index) => {
        const isTest = index % 10 === 0;
        return {
            id: `01p${String(index).padStart(15, '0')}`,
            name: `SampleClass${String(index).padStart(2, '0')}`,
            isTest,
            apiVersion: 66,
            linesOfCode: 100 + index,
            characters: 2000 + index,
            linesCovered: isTest ? undefined : 50 + index,
            linesUncovered: isTest ? undefined : 50 - index,
            coverage: isTest ? undefined : 50 + index,
            grade: GRADES[index % GRADES.length],
            findings: '',
            lastModifiedDate: '2026-01-15T10:00:00.000Z',
            lastModifiedBy: 'Integration User'
        };
    });
    return {
        classes,
        coverageAvailable,
        triggerCharacters: 500,
        coverageMessage: coverageAvailable
            ? undefined
            : 'Code coverage is unavailable (Tooling API responded with 401 Unauthorized).'
    };
}

async function flushPromises() {
    for (let i = 0; i < 10; i += 1) {
        // eslint-disable-next-line no-await-in-loop
        await Promise.resolve();
    }
}

async function renderComponent(report = buildReport()) {
    const element = createElement('c-apex-class-health', { is: ApexClassHealth });
    document.body.appendChild(element);
    getApexClassHealth.emit(report);
    await Promise.resolve();
    return element;
}

const getTable = (element) => element.shadowRoot.querySelector('c-apex-class-health-datatable');
const getPageLabel = (element) => element.shadowRoot.querySelector('.page-label').textContent;

describe('c-apex-class-health', () => {
    afterEach(() => {
        while (document.body.firstChild) {
            document.body.firstChild.remove();
        }
        jest.clearAllMocks();
        jest.useRealTimers();
    });

    it('renders the first page of classes', async () => {
        const element = await renderComponent();

        expect(getTable(element).data).toHaveLength(25);
        expect(getPageLabel(element)).toBe('Page 1 of 2');
    });

    it('filters by search term after the debounce delay', async () => {
        jest.useFakeTimers();
        const element = await renderComponent();

        element.shadowRoot
            .querySelector('lightning-input')
            .dispatchEvent(new CustomEvent('change', { detail: { value: 'class07' } }));
        jest.advanceTimersByTime(300);
        await Promise.resolve();

        expect(getTable(element).data.map((row) => row.name)).toEqual(['SampleClass07']);
    });

    it('filters by grade', async () => {
        const element = await renderComponent();

        element.shadowRoot
            .querySelector('lightning-combobox[data-filter="gradeFilter"]')
            .dispatchEvent(new CustomEvent('change', { detail: { value: 'D' } }));
        await Promise.resolve();

        const rows = getTable(element).data;
        expect(rows).toHaveLength(7);
        expect(rows.every((row) => row.grade === 'D')).toBe(true);
    });

    it('sorts by the selected column', async () => {
        const element = await renderComponent();

        getTable(element).dispatchEvent(
            new CustomEvent('sort', { detail: { fieldName: 'coveragePercent', sortDirection: 'desc' } })
        );
        await Promise.resolve();

        expect(getTable(element).data[0].name).toBe('SampleClass29');
    });

    it('moves to the next page', async () => {
        const element = await renderComponent();

        element.shadowRoot.querySelector('lightning-button-icon[data-page="next"]').click();
        await Promise.resolve();

        expect(getTable(element).data).toHaveLength(5);
        expect(getPageLabel(element)).toBe('Page 2 of 2');
    });

    it('shows a notice when code coverage is unavailable', async () => {
        const element = await renderComponent(buildReport({ coverageAvailable: false }));

        expect(element.shadowRoot.querySelector('.coverage-notice').textContent).toContain(
            'Code coverage is unavailable'
        );
    });

    it('shows the error when classes cannot be loaded', async () => {
        const element = createElement('c-apex-class-health', { is: ApexClassHealth });
        document.body.appendChild(element);

        getApexClassHealth.error({ message: 'Insufficient access' });
        await Promise.resolve();

        expect(element.shadowRoot.querySelector('[role="alert"]').textContent).toContain('Insufficient access');
    });

    it('counts triggers but not test classes toward Apex characters used, like Setup', async () => {
        const element = await renderComponent();

        // 27 non-test classes of 2000 + index characters each, plus 500 trigger characters.
        expect(element.shadowRoot.querySelector('.apex-characters lightning-formatted-number').value).toBe(54905);
    });

    it('runs tests for the selected classes', async () => {
        runTests.mockResolvedValue({ jobId: JOB_ID, testClassIds: [TEST_CLASS_ID], classesWithoutTests: [] });
        const element = await renderComponent();
        const rows = getTable(element).data;

        getTable(element).dispatchEvent(
            new CustomEvent('rowselection', { detail: { selectedRows: [rows[1], rows[2]] } })
        );
        await flushPromises();
        element.shadowRoot.querySelector('lightning-button[data-id="run-tests"]').click();
        await flushPromises();

        expect(runTests).toHaveBeenCalledWith({ classIds: [rows[1].id, rows[2].id] });
        expect(element.shadowRoot.querySelector('.run-status')).not.toBeNull();
    });

    it('shows which classes a finished test run covered', async () => {
        jest.useFakeTimers();
        const coveredClasses = [
            { id: '01p000000000000001', name: 'SampleClass01', coverage: 51, linesCovered: 51, linesTotal: 100 }
        ];
        runTests.mockResolvedValue({ jobId: JOB_ID, testClassIds: [TEST_CLASS_ID], classesWithoutTests: [] });
        getTestRunStatus.mockResolvedValue({
            isComplete: true,
            classesTotal: 1,
            classesCompleted: 1,
            methodsPassed: 3,
            failures: []
        });
        getClassesCoveredByTests.mockResolvedValue(coveredClasses);
        const element = await renderComponent();

        getTable(element).dispatchEvent(
            new CustomEvent('rowaction', { detail: { action: { name: 'run_tests' }, row: { id: TEST_CLASS_ID } } })
        );
        await flushPromises();
        jest.advanceTimersByTime(5000);
        await flushPromises();

        expect(getTestRunStatus).toHaveBeenCalledWith({ jobId: JOB_ID });
        expect(getClassesCoveredByTests).toHaveBeenCalledWith({ testClassIds: [TEST_CLASS_ID] });
        expect(ApexClassCoverageModal.open).toHaveBeenCalledWith(
            expect.objectContaining({ label: 'Test Run Results', items: coveredClasses })
        );
        expect(element.shadowRoot.querySelector('.last-run').textContent).toContain('3 passed, 0 failed');
    });

    it('opens the coverage popup when a coverage percent is clicked', async () => {
        const coveringTests = [
            { id: TEST_CLASS_ID, name: 'SampleClass00', coverage: 80, linesCovered: 8, linesTotal: 10 }
        ];
        getTestsCoveringClass.mockResolvedValue(coveringTests);
        const element = await renderComponent();
        const row = getTable(element).data[1];

        getTable(element).dispatchEvent(new CustomEvent('coverageclick', { detail: { rowId: row.id } }));
        await flushPromises();

        expect(getTestsCoveringClass).toHaveBeenCalledWith({ classId: row.id });
        expect(ApexClassCoverageModal.open).toHaveBeenCalledWith(
            expect.objectContaining({ label: `Tests Covering ${row.name}`, items: coveringTests })
        );
    });
});
